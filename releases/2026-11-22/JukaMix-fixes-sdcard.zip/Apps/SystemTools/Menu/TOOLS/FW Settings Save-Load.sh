#!/bin/sh
export LD_LIBRARY_PATH=./lib:/mnt/SDCARD/System/lib:$LD_LIBRARY_PATH
export PATH="/mnt/SDCARD/System/bin:/mnt/SDCARD/System/usr/trimui/scripts:$PATH"
SEVENZ="/mnt/SDCARD/System/bin/7zz"

read -r current_device </etc/trimui_device.txt
case "$current_device" in
tsps)
    wpa_supplicant_PATH=etc/wifi/wpa_supplicant/wpa_supplicant.conf
    ;;
*)
    wpa_supplicant_PATH=etc/wifi/wpa_supplicant.conf
    ;;
esac

# Function to restore individual files from the archive
restore_file() {
    path="$1"
    relative_path="${path#/}" # Remove leading "/" from the path
    [ -n "$relative_path" ] && $SEVENZ x "$ARCHIVE_PATH" "$relative_path" -y -o/ && echo "Restored: $path"
    chmod 644 "$path"
    chown root:root "$path"
}

# Function to show help
show_help() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -h, --help                    Show this help message"
    echo "  -b, --backup                  Create a backup"
    echo "  -r, --restore FILE [TYPE]     Restore from backup file"
    echo ""
    echo "Restore types (optional):"
    echo "  all                           Restore all settings (default)"
    echo "  wifi                          Restore only wifi settings"
    echo "  joystick                      Restore only joystick calibration"
    echo "  mainui                        Restore only MainUI settings"
    echo "  history                       Restore only command history"
    echo ""
    echo "Examples:"
    echo "  $0 --backup"
    echo "  $0 --restore /path/to/backup.7z"
    echo "  $0 --restore /path/to/backup.7z wifi"
}

# Parse command line arguments
if [ $# -gt 0 ]; then
    case "$1" in
    -h | --help)
        show_help
        exit 0
        ;;
    -b | --backup)
        selected_action="Backup"
        ;;
    -r | --restore)
        if [ -z "$2" ]; then
            echo "Error: Backup file path required for restore operation"
            show_help
            exit 1
        fi
        selected_action="Restore"
        ARCHIVE_PATH="$2"
        restore_type="${3:-all}"
        ;;
    *)
        echo "Error: Unknown option '$1'"
        show_help
        exit 1
        ;;
    esac
else
    # Interactive mode - use selector
    selector_output=$(selector -fs 200 -t "Choose an action to perform:                           (B to cancel)" -c "Backup" "Restore" | grep "You selected")
    selected_action="${selector_output#*: }"
fi

case "$selected_action" in
"Backup")
    echo "Backup mode for $current_device"
    ARCHIVE_PATH="/mnt/SDCARD/System/backups/firmware_settings/$current_device/backup_$(date +'%Y%m%d-%Hh%M-%S').7z"
    mkdir -p "/mnt/SDCARD/System/backups/firmware_settings/$current_device/"
    cd /

    # Create the backup archive including the specified files
    $SEVENZ a "$ARCHIVE_PATH" \
        "$wpa_supplicant_PATH" \
        mnt/UDISK/system.json \
        mnt/UDISK/joypad.config \
        mnt/UDISK/joypad_right.config \
        root/.ash_history

    # Show info screen only in interactive mode
    if [ $# -eq 0 ]; then
        infoscreen.sh -m "\"backup_$(date +'%Y%m%d-%Hh%M-%S').7z\"    saved." -t 2
    else
        echo "backup_$(date +'%Y%m%d-%Hh%M-%S').7z"
    fi

    sync
    ;;

"Restore")

    echo "Restore mode for $current_device"

    # If not in command line mode, ask the user to select the backup file
    if [ -z "$ARCHIVE_PATH" ]; then
        selector_output=$(selector -fs 150 -t "Choose a backup file to restore:" -d "/mnt/SDCARD/System/backups/firmware_settings/$current_device/" | grep "You selected")
        # B pressed in the file chooser: the selector prints no "You selected" line
        if [ -z "$selector_output" ]; then
            infoscreen.sh -m "Exiting..."
            exit 0
        fi
        ARCHIVE_PATH="${selector_output#*: }"
    fi

    # Check if the backup archive file exists
    if [ ! -f "$ARCHIVE_PATH" ]; then
        echo "Backup archive not found: $ARCHIVE_PATH"
        exit 1
    fi

    # If not in command line mode, ask what to restore
    if [ -z "$restore_type" ]; then
        selector_output=$(selector -fs 200 -t "Choose what you want to restore:" -c "All" "Wifi settings" "Joystick calibration" "MainUI settings" "Command history" | grep "You selected")
        selected_restore="${selector_output#*: }"
        case "$selected_restore" in
        "All") restore_type="all" ;;
        "Wifi settings") restore_type="wifi" ;;
        "Joystick calibration") restore_type="joystick" ;;
        "MainUI settings") restore_type="mainui" ;;
        "Command history") restore_type="history" ;;
        *)
            infoscreen.sh -m "Exiting..."
            exit
            ;;
        esac
    fi

    case "$restore_type" in
    "all")
        $SEVENZ x "$ARCHIVE_PATH" -y -o/ >/dev/null 2>&1 && echo "All settings restored."
        restore_message="All settings restored."
        ;;
    "wifi")
        restore_file "/$wpa_supplicant_PATH"
        restore_message="Wifi settings restored."
        ;;
    "joystick")
        restore_file "/mnt/UDISK/joypad.config"
        restore_file "/mnt/UDISK/joypad_right.config"
        restore_message="Joystick calibration restored."
        ;;
    "mainui")
        restore_file "/mnt/UDISK/system.json"
        restore_message="MainUI settings restored."
        ;;
    "history")
        restore_file "/root/.ash_history"
        restore_message="Command history restored."
        ;;
    *)
        echo "No valid option selected."
        # Show info screen only in interactive mode
        if [ $# -eq 0 ]; then
            infoscreen.sh -m "Exiting..."
        fi
        exit 1
        ;;
    esac

    # A calibration file restored from another device (or from an older firmware)
    # can be unusable for the running daemon: it then loses one half of an axis,
    # which looks like a dead or reversed stick.  Check it right after the
    # restore so the user knows before starting a game.
    case "$restore_type" in
    all | joystick)
        STICK="/mnt/SDCARD/System/usr/trimui/scripts/stick_diag.sh"
        if [ -x "$STICK" ]; then
            "$STICK" -q ensure
            stick_state=$("$STICK" -q status | tr -d '\r')
            case "$stick_state" in
            OK*) ;;
            *) restore_message="$restore_message Analog sticks: $stick_state - recalibrate in Settings > System > Calibrate Joystick." ;;
            esac
        fi
        ;;
    esac

    # Show info screen only in interactive mode
    if [ $# -eq 0 ]; then
        infoscreen.sh -m "$restore_message" -t 2
    else
        echo "$restore_message"
    fi

    sync
    ;;

*)
    # If no valid action is selected (B pressed), exit
    echo "No valid action selected."
    # Show info screen only in interactive mode
    if [ $# -eq 0 ]; then
        infoscreen.sh -m "Exiting..."
    fi
    exit 1
    ;;
esac
