#!/bin/sh
echo "$0" "$*"

export PATH="/mnt/SDCARD/System/usr/trimui/scripts/:/mnt/SDCARD/System/bin:$PM_DIR:${PATH:+:$PATH}"
export LD_LIBRARY_PATH="/usr/trimui/lib:/mnt/SDCARD/System/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
read -r current_device </etc/trimui_device.txt

# Switch audio and set hotkey
ra_audio_switcher.sh
touch /var/trimui_inputd/ra_hotkey

RA_DIR=/mnt/SDCARD/RetroArch
cd "$RA_DIR"

# Auto-detect best binary for this device
files=$(ls /mnt/SDCARD/RetroArch/ra64.trimui_${current_device}_*.bin 2>/dev/null)
BEST_BIN=$(echo "$files" | sort -V | tail -n 1)

# Brick Pro falls back to Brick binary if no dedicated build exists
if [ -z "$BEST_BIN" ] && [ "$current_device" = "brickpro" ]; then
    files=$(ls /mnt/SDCARD/RetroArch/ra64.trimui_brick_*.bin 2>/dev/null)
    BEST_BIN=$(echo "$files" | sort -V | tail -n 1)
fi

# Run the button_state.sh script
/mnt/SDCARD/System/usr/trimui/scripts/button_state.sh Y
if [ $? -eq 10 ]; then

    # Build the selector's choice list with "$@" so every filename is passed as
    # its own argument: no eval, no re-splitting, and names containing spaces
    # survive intact.
    set --
    for f in /mnt/SDCARD/RetroArch/ra64.trimui_${current_device}_*.bin; do
        [ -f "$f" ] || continue
        set -- "$@" "$(basename "$f")"
    done

    # Also include Brick binaries for Brick Pro users
    if [ "$current_device" = "brickpro" ]; then
        for f in /mnt/SDCARD/RetroArch/ra64.trimui_brick_*.bin; do
            [ -f "$f" ] || continue
            set -- "$@" "$(basename "$f")"
        done
    fi

    if [ $# -eq 0 ]; then
        echo "No files found for device $current_device."
        exit 1
    fi

    # "-c <choices> ..." is selector's custom-string list and must be the last flag.
    SELECTED_FILE=$(/mnt/SDCARD/System/bin/selector -fs 120 -c "$@" | grep "You selected")
    SELECTED_FILE=$(printf '%s\n' "$SELECTED_FILE" | sed 's/^.*: //')

fi

if [ -z "$SELECTED_FILE" ]; then
    if [ -n "$BEST_BIN" ]; then
        SELECTED_FILE="$(basename "$BEST_BIN")"
    else
        SELECTED_FILE="ra64.trimui"
    fi
fi

# Sidecar: records what RetroArch is doing into System/logs/ra_probe.log (read-only, detached;
# see System/usr/trimui/scripts/ra_probe.sh). Skipped when the script is not present.
PROBE=/mnt/SDCARD/System/usr/trimui/scripts/ra_probe.sh
if [ -f "$PROBE" ]; then
    sh "$PROBE" "$SELECTED_FILE" >/dev/null 2>&1 &
fi

HOME="$RA_DIR/" "$RA_DIR/$SELECTED_FILE"
